# Autotest endpoint config file bars receiver via middleware
#
#
to_ep=http://localhost:4848/R4

toservice=TKW0004
fromservice=TKW0004
sendtls=No


# required for non TLSMA tls Sender and TLSMA Receiver
# paths for docker execution
truststore=/home/service/TKW/config/FHIR_BaRS/autotest_config/endpoint_configs/certs/nis.jks
keystore=/home/service/TKW/config/FHIR_BaRS/autotest_config/endpoint_configs/certs/ec2-18-170-14-253.eu-west-2.compute.amazonaws.com.jks

#path for local execution
#truststore=/home/shul1/Documents/TKW_BaRS/config/FHIR_BaRS/autotest_config/endpoint_configs/certs/nis.jks
#keystore=/home/shul1/Documents/TKW_BaRS/config/FHIR_BaRS/autotest_config/endpoint_configs/certs/ec2-18-170-14-253.eu-west-2.compute.amazonaws.com.jks
