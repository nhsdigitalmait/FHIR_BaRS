# secure bars application
oauth_apikey=nmTVHM8kyYsoDl4giZVdo8fJseJ7oG58
oauth_redirect=ec2-35-178-82-68.eu-west-2.compute.amazonaws.com
oauth_secret=Iab9lW17A4avgA29
oauth_server=int.api.service.nhs.uk

# client credentials for docker
oauth_private_key=/home/service/TKW/config/FHIR_BaRS/autotest_config/endpoint_configs/certs/MAITBaRSSender-INT-4
oauth_jwt_template=/home/service/TKW/config/FHIR_BaRS/autotest_config/jwt_templates/bars_oauth_jwt_template.txt

# client credentials for local
#oauth_private_key=/home/shul1/Documents/TKW_BaRS/config/FHIR_BaRS/autotest_config/endpoint_configs/certs/MAITBaRSSender-INT-4
#oauth_jwt_template=/home/shul1/Documents/TKW_BaRS/config/FHIR_BaRS/autotest_config/jwt_templates/bars_oauth_jwt_template.txt


oauth_kid=MAITBaRSSender-INT-4
